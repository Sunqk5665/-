#ifndef __Key_H__
#define __Key_H__

#include <reg52.h>
#include <intrins.h>




void ReadKey(void);


#endif